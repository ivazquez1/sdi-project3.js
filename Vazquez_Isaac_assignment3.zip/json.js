// JSON data

var jsonData = {

	"dogs":
	    [
	        {
	        	"dogsName": "Odie",
	        	"dogsType": "YorkShire",
	        	"dogsAge":  8
	        },
	        {
	        	"dogsName": "Bentley",
	        	"dogsType":  "YorkShire",
	        	"dogsAge":   3
	        },
	        {
	        	"dogsName": "Kita",
	        	"dogsType": "Husky",
	        	"dogsAge":   1
	        }
	     ]
	     
};	        			